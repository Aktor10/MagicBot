module.exports ={
    name: "serverinfo",
    aliases:["si","server-info"],
    code:`$addField[1;**$serverName**;__Owner:__ **@$ownerID**
      __Members:__ **$membersCount**
    __Bots:__ **$botCount**
  __Commands:__ **$commandsCount**
__Channels:__ **$channelCount**
__Emojis:__ **$emojiCount**
__Bans:__ **$banCount**]`
  }