module.exports ={
    name: "botinfo",
    aliases:["bi","bot-info"],
    code:`$addField[1;**MagicBot 🪄**;__Created:__ **10.08.2022**
    __Servers:__ **$serverCount**
  __Commands:__ **$commandsCount**
__Memory Usage:__ **$ram**
__CPU Usage:__ **$cpu**]`
  }