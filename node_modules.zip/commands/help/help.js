module.exports ={
    name: "help",
    aliases:["h"],
    code:`pomoc`
  }